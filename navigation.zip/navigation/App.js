import * as React from 'react';
import { View, TouchableOpacity } from 'react-native';
import { NavigationContainer, getFocusedRouteNameFromRoute } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import TollywoodScreen from './TollywoodScreen';
import BollywoodScreen from './BollywoodScreen';
import SettingScreen from './SettingScreen';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();

const NavigationDrawerStructure = (props) => {
    const toggleDrawer = () => {
        props.navigationProps.toggleDrawer();
    };

    return (
        <View style={{ flexDirection: 'row' }}>
            <TouchableOpacity onPress={() => toggleDrawer()}>
            </TouchableOpacity>
        </View>
    );
};

const getHeaderTitle = (route) => {
    const routeName = getFocusedRouteNameFromRoute(route) ?? 'Feed';

    switch (routeName) {
        case 'TollywoodScreen':
            return 'Tollywood';
        case 'BollywoodScreen':
            return 'Bollywood';
        case 'BottomTabStack':
            return 'Home';
    }
};

const BottomTabStack = () => {
    return (
        <Tab.Navigator
            initialRouteName="TollywoodScreen">
            <Tab.Screen name="TollywoodScreen" component={TollywoodScreen}
                options={{
                }}
            />
            <Tab.Screen
                name="BollywoodScreen"
                component={BollywoodScreen}
                options={{
                }}
            />
        </Tab.Navigator>
    );
};

const Tollywood = ({ navigation }) => {
    return (
        <Stack.Navigator initialRouteName="TollywoodScreen">
            <Stack.Screen
                name="Bollywood"
                component={BottomTabStack}
                options={({ route }) => ({
                    headerTitle: getHeaderTitle(route),
                    headerLeft: () => (
                        <NavigationDrawerStructure
                            navigationProps={navigation}
                        />
                    ),
                    headerStyle: {
                        backgroundColor: '#f4511e', //Set Header color
                    },
                    headerTintColor: '#fff', //Set Header text color
                    headerTitleStyle: {
                        fontWeight: 'bold', //Set Header text style
                    },
                })}
            />
        </Stack.Navigator>
    );
};

const Settings = ({ navigation }) => {
    return (
        <Stack.Navigator>
            <Stack.Screen
                name="SettingScreen"
                component={SettingScreen}
                options={{
                    title: 'Settings', //Set Header Title
                }}
            />
        </Stack.Navigator>
    );
};

const App = () => {
    return (
        <NavigationContainer>
            <Drawer.Navigator
                drawerContentOptions={{
                    activeTintColor: '#e91e63',
                    itemStyle: { marginVertical: 5 },
                }}>
                <Drawer.Screen
                    name="Welcome"
                    options={{ drawerLabel: 'Welcome' }}
                    component={Tollywood}
                />
                <Drawer.Screen
                    name="Favourite Videos"
                    options={{ drawerLabel: 'Favourite videos' }}
                    component={Settings}
                />
                 <Drawer.Screen
                    name="Liked Videos"
                    options={{ drawerLabel: 'Liked Videos' }}
                    component={Settings}
                />
                 <Drawer.Screen
                    name="Saved Videos"
                    options={{ drawerLabel: 'Saved Videos' }}
                    component={Settings}
                />
            </Drawer.Navigator>
        </NavigationContainer>
    );
};

export default App;
