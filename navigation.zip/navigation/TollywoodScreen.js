import * as React from 'react';
import { View, Text, SafeAreaView } from 'react-native';
import Carousel from './image'

const TollywoodScreen = () => {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, padding: 16 }}>
        <Carousel />
      </View>
    </SafeAreaView>
  );
};

export default TollywoodScreen;
